<?php

namespace Twig\Node;

class_exists('Twig_Node_If');

if (\false) {
    class IfNode extends \Twig_Node_If
    {
    }
}
