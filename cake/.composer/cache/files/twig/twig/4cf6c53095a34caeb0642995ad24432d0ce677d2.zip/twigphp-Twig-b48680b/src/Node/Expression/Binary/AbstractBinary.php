<?php

namespace Twig\Node\Expression\Binary;

class_exists('Twig_Node_Expression_Binary');

if (\false) {
    class AbstractBinary extends \Twig_Node_Expression_Binary
    {
    }
}
