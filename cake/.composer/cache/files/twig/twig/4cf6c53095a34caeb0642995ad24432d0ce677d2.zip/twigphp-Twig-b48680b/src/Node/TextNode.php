<?php

namespace Twig\Node;

class_exists('Twig_Node_Text');

if (\false) {
    class TextNode extends \Twig_Node_Text
    {
    }
}
