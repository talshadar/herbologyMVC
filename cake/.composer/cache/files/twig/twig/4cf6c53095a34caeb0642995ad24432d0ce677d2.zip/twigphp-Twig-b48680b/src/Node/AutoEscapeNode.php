<?php

namespace Twig\Node;

class_exists('Twig_Node_AutoEscape');

if (\false) {
    class AutoEscapeNode extends \Twig_Node_AutoEscape
    {
    }
}
