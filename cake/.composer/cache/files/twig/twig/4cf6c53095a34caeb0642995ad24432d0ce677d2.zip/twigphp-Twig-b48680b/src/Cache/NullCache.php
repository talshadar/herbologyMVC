<?php

namespace Twig\Cache;

class_exists('Twig_Cache_Null');

if (\false) {
    class NullCache extends \Twig_Cache_Null
    {
    }
}
