<?php

namespace Twig\TokenParser;

class_exists('Twig_TokenParser_Block');

if (\false) {
    class BlockTokenParser extends \Twig_TokenParser_Block
    {
    }
}
