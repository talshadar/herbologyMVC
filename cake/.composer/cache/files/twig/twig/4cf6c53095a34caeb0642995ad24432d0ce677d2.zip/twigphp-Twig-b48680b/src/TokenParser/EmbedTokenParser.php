<?php

namespace Twig\TokenParser;

class_exists('Twig_TokenParser_Embed');

if (\false) {
    class EmbedTokenParser extends \Twig_TokenParser_Embed
    {
    }
}
