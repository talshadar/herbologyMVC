<?php

namespace Twig\RuntimeLoader;

class_exists('Twig_ContainerRuntimeLoader');

if (\false) {
    class ContainerRuntimeLoader extends \Twig_ContainerRuntimeLoader
    {
    }
}
