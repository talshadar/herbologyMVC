<?php

namespace Twig\Extension;

class_exists('Twig_Extension_StringLoader');

if (\false) {
    class StringLoaderExtension extends \Twig_Extension_StringLoader
    {
    }
}
