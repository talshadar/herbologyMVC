<?php

namespace Twig\Node;

class_exists('Twig_Node_Module');

if (\false) {
    class ModuleNode extends \Twig_Node_Module
    {
    }
}
