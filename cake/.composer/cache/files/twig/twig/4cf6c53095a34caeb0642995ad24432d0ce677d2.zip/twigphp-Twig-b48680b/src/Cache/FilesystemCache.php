<?php

namespace Twig\Cache;

class_exists('Twig_Cache_Filesystem');

if (\false) {
    class FilesystemCache extends \Twig_Cache_Filesystem
    {
    }
}
