<?php

namespace Twig;

class_exists('Twig_TemplateWrapper');

if (\false) {
    class TemplateWrapper extends \Twig_TemplateWrapper
    {
    }
}
