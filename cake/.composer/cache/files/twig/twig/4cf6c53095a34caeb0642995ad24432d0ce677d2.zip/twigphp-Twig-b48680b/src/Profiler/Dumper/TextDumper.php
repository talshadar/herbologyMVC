<?php

namespace Twig\Profiler\Dumper;

class_exists('Twig_Profiler_Dumper_Text');

if (\false) {
    class TextDumper extends \Twig_Profiler_Dumper_Text
    {
    }
}
