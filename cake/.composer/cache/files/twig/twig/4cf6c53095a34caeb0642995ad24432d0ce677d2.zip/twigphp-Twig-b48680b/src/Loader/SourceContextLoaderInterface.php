<?php

namespace Twig\Loader;

class_exists('Twig_SourceContextLoaderInterface');

if (\false) {
    interface SourceContextLoaderInterface extends \Twig_SourceContextLoaderInterface
    {
    }
}
