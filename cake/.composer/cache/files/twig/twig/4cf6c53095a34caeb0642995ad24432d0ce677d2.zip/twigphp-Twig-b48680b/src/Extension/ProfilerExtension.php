<?php

namespace Twig\Extension;

class_exists('Twig_Extension_Profiler');

if (\false) {
    class ProfilerExtension extends \Twig_Extension_Profiler
    {
    }
}
