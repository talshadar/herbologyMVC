<?php

namespace Twig\Node\Expression\Unary;

class_exists('Twig_Node_Expression_Unary_Neg');

if (\false) {
    class NegUnary extends \Twig_Node_Expression_Unary_Neg
    {
    }
}
