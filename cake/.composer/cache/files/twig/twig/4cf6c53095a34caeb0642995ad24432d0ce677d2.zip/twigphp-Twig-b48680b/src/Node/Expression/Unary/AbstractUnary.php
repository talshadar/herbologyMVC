<?php

namespace Twig\Node\Expression\Unary;

class_exists('Twig_Node_Expression_Unary');

if (\false) {
    class AbstractUnary extends \Twig_Node_Expression_Unary
    {
    }
}
