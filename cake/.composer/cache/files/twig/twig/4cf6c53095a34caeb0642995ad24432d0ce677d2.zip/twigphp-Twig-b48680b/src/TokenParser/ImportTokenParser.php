<?php

namespace Twig\TokenParser;

class_exists('Twig_TokenParser_Import');

if (\false) {
    class ImportTokenParser extends \Twig_TokenParser_Import
    {
    }
}
