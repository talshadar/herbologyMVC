<?php
// @deprecated Load new class and alias
class_exists('Cake\Http\Response');
deprecationWarning('Use Cake\Http\Response instead of Cake\Network\Response.');
