<?php
// @deprecated Backward compatibility alias
class_alias('Cake\Http\Exception\NotImplementedException', 'Cake\Network\Exception\NotImplementedException');
deprecationWarning('Use Cake\Http\Exception\NotImplementedException instead of Cake\Network\Exception\NotImplementedException.');
