<?php
// @deprecated Backward compatibility alias
class_alias('Cake\Http\Exception\HttpException', 'Cake\Network\Exception\HttpException');
deprecationWarning('Use Cake\Http\Exception\HttpException instead of Cake\Network\Exception\HttpException.');
