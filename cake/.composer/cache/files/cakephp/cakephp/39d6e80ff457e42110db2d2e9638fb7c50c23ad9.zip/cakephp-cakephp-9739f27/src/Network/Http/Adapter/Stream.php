<?php
// @deprecated Load new class and alias.
class_exists('Cake\Http\Client\Adapter\Stream');
deprecationWarning('Use Cake\Http\Client\Adapter\Stream instead of Cake\Network\Http\Adapter\Stream.');
