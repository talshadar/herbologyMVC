<?php
// @deprecated Backwards compatibility alias
class_alias('Cake\Http\Session\DatabaseSession', 'Cake\Network\Session\DatabaseSession');
deprecationWarning('Use Cake\Http\Session\DatabaseSession instead of Cake\Network\Session\DatabaseSession.');
