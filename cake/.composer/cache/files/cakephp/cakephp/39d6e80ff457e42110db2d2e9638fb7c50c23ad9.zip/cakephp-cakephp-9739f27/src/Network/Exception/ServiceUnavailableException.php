<?php
// @deprecated Backward compatibility alias
class_alias('Cake\Http\Exception\ServiceUnavailableException', 'Cake\Network\Exception\ServiceUnavailableException');
deprecationWarning('Use Cake\Http\Exception\ServiceUnavailableException instead of Cake\Network\Exception\ServiceUnavailableException.');
