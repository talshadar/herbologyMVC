# Backers

You can join them in supporting Phinx development by [pledging on Patreon](https://www.patreon.com/robmorgan)! Backers in the same pledge level appear in the order of pledge date.

### Gold Sponsor

 * [Available!](https://www.patreon.com/robmorgan)

---

### Silver Sponsors

 * [Available!](https://www.patreon.com/robmorgan)

---

### Bronze Sponsors

 * [Available!](https://www.patreon.com/robmorgan)

---

### $30+

- [Available!](https://www.patreon.com/robmorgan)

---

### $5+

- [Available!](https://www.patreon.com/robmorgan)
